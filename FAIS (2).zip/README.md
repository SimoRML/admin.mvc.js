# admin.mvc.js
admin vue js app
