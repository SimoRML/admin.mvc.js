app.directive('langues', function() { 
  return { 
    restrict: 'E', 
    scope: { 
    }, 
    templateUrl: 'js/angular/directives/langues.html' 
  }; 
});